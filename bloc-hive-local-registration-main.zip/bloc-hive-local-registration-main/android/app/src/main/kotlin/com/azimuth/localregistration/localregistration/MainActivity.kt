package com.azimuth.localregistration.localregistration

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
